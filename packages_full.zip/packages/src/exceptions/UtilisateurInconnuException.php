<?php

namespace FormationPHP\exceptions;

class UtilisateurInconnuException extends \Exception
{
    // Heriter de Exception permet de transformer notre 
    // classe en classe d'erreurs
}