<?php
namespace FormationPHP\service;

use FormationPHP\dao\UserDAO;
use FormationPHP\exceptions\UtilisateurInconnuException;

/**
 * @author Felix SPORTELLI
 * 
 * Cette classe permet de gérer tout l'aspect métier d'un utilisateur
 * 
 */
class UserService 
{

    /**
     * attribut permettant d'accéder à la DAO de User
     * 
     * @var UserDAO 
     */
    private $userDAO;

    function __construct($userDAO = null)
    {
        $this->userDAO = $userDAO;
    }

    /**
     * Permet de récupérer toutes les informations utilisateurs 
     * en fonction de son identifiant 
     * 
     * @param string $identifiant identifiant de l'utilisateur à chercher en base
     * @return \FormationPHP\model\User utilisateur trouvé en base
     * @throws UtilisateurInconnuException si utilisateur non trouvé par la DAO
     */
    function recupByIdentifiant(string $identifiant)
    {
        // Accéder à la DAO
        $userDAO = ($this->userDAO != null) ? $this->userDAO : new UserDAO();
        $user = $userDAO->getByIdentifiant($identifiant);

        // Si pas d'utilisateur trouvé, je jette une exception de type UtilisateurInconnuException
        if ($user == null)
            throw new UtilisateurInconnuException("utilisateur " . $identifiant . " inconnu");

        return $user;
    }
}