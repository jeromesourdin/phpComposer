<table>
    <tr>
        <td>
            <?php 
            echo "nom";
            ?>
        </td>
        <td>
            <?php
            echo "prenom";
            ?>
        </td>
    </tr>
</table>
