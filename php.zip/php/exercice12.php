<?php

function bonjour()
{
    echo "bonjour <br />";
}

function afficheSomme ( $a , $b) 
{
    echo $a+$b .  "<br />";
}

function afficheSommeType( int $a , int $b)
{
    echo $a+$b .  "<br />";
}

function getSomme( int $a , int $b )
{
    return $a+$b;
}

// Fonctionne uniquement PHP7
function getSomme7 (int $a , int $b) : int 
{
    return $a+$b;
}

bonjour();
afficheSomme(1 , 2);
afficheSommeType( 1 , 2 );
afficheSommeType( 1 , 2.0 );
//afficheSomme( 1 , "a" );
//afficheSommeType( 1 , "a" );
$somme = getSomme(1 , 2);
echo "somme = $somme <br />";
$somme = getSomme7(1 , 2);
echo "somme = $somme <br /> <br />";

//TODO: 
// Definir un array $utilisateurs 
// Appeler une fonction afficheUtilisateurs($utilisateurs) 

function afficheUtilisateurs($utilisateurs) 
{
    foreach ($utilisateurs as $nom) {
        echo "$nom - ";
    }
    echo "<br /><br />";
}

function ajouteUtilisateurs ( &$utilisateurs, $nom )
{
    array_push ($utilisateurs, $nom);
    afficheUtilisateurs ($utilisateurs);
}

function ajouteUtilisateurs2 ( $utilisateurs, $nom )
{
    array_push ($utilisateurs, $nom);
    return $utilisateurs;
}

function calculNbUtilisateurs ( $utilisateurs , &$totalUtilisateurs )
{
    $totalUtilisateurs = count($utilisateurs);
}

$users = array ("felix", "aurelie");
afficheUtilisateurs($users);
echo "<br />";
ajouteUtilisateurs($users, "leo");
echo "<br />";

$nouveauxUtilisateurs = 
    ajouteUtilisateurs2($users, "lea");
afficheUtilisateurs ($nouveauxUtilisateurs);

$totalUtilisateurs = 0; 
calculNbUtilisateurs($users, $totalUtilisateurs);
echo "<br/><br/>Nb Users:" . $totalUtilisateurs . "<br />";

function ajoutUtilisateurOptionnel(&$users , $nom = "inconnu")
{
    array_push ($users, $nom);
    return $users;
}

ajoutUtilisateurOptionnel($users, "lei");
afficheUtilisateurs($users);
ajoutUtilisateurOptionnel($users);
afficheUtilisateurs($users);



