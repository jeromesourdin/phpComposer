<?php

// Définition de contrat 
interface IDAO
{
    function getById($id);
    function create($dossier);
    function delete($dossier);
}

/**
 * @author Nicolas
 */
class DossierCAFDAO implements IDAO
{
    function getById($id){}
    function getByName($name){}
    function createDossier($dossier){}
    function supprimerDossier($dossier){}
    //...
}

/**
 * @author Jerome 
 */
class DossierPEDAO 
{
    function recupParIdentifiant($id){}
    function nouveau(DossierPE $dossier){}
    function supprimer($dossier){}
}


class DossierPE {

}