<?php

// Définition de contrat 
interface IDAO
{
    function getById($id);
    function create($dossier);
    function delete($dossier);
}