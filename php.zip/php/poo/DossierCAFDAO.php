<?php
/**
 * @author Nicolas
 */
class DossierCAFDAO implements IDAO
{
    function getById($id){}
    function getByName($name){}
    function createDossier($dossier){}
    function supprimerDossier($dossier){}
    //...
}
