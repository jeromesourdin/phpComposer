<?php 
class Utilisateur 
{
    private $nom;
    public function getNom() { return $this->nom; }
    public function setNom($nom) { $this->nom = $nom; }
}
class UserDAO
{
    function __construct()
    {
        echo "userDAO initialise ... <br />";
    }
    function getByIdentifiant($identifiant)
    {
        $user = new Utilisateur();
        $user->setNom("SPORTELLI");
        return $user;
    }
    function __destruct()
    {
        echo "userDAO libere ... <br />";
    }
}
class UserServices 
{
    function __construct() {
        echo "userServices initialise <br/>";
    }
    function __destruct(){
        echo "userServices libere <br/>";
    }
    function recupByIdentifiant($identifiant)
    {
        $userDAO = new UserDAO();
        $user = $userDAO->getByIdentifiant($identifiant);
        return $user;
    }
}

// INDEX
$userServices = new UserServices();
$utilisateur = $userServices->recupByIdentifiant("felix");
echo "j'ai recupere l'utilisateur " . $utilisateur->getNom() . "<br/>";