<?php 

class Adresse 
{
    public $numero;
    public $voie;
    public $ville;

    function affiche()
    {
        return "$this->numero - $this->voie - $this->ville";
    }
}

class Personne 
{
    // Attributs:  
    private $nom;
    private $prenom;
    private $age;
    private $adresse = null; 

    // Méthodes: 
    function disBonjour()
    {
        $str = "Bonjour, je suis " 
                . $this->nom 
                . " et j'ai " 
                . $this->age . " ans.";
        if ($this->adresse)
            $str .= " et j'habite " . $this->adresse->affiche();
        return $str;
    }

    // Getters / Setters 
    function setNom($nom)
    {
        $this->nom = strtoupper($nom);
    }

    function getNom() 
    {
        return $this->nom;
    }

    function setAge($age)
    {
        $this->age = $age;
    }

    function getAge()
    {
        return $this->age;
    }

    function setPrenom($prenom)
    {
        $this->prenom = $prenom;
    }

    function getPrenom()
    {
        return $this->prenom;
    }

    function setAdresse($adresse)
    {
        $this->adresse = $adresse;
    }

    function getAdresse()
    {
        return $this->adresse;
    }
}

class Fonctionnaire extends Personne
{
    private $titularise;

    function isTitulaire()
    {
        return $this->titularise;
    }

    function setTitularise(bool $titularise)
    {
        $this->titularise = $titularise;
    }

    function disBonjour()
    {
        $message = parent::disBonjour();
        if ($this->titularise)
            $message .= "je suis titulaire";
        else
            $message .= "grrr ..." ;
        $message .= "<br/>";
        return $message;
    }
    
}

class Affichage
{
    function go(Personne $personne)
    {
        return $personne->disBonjour();
    }

    function go2(IDAO $dao)
    {
        $dao->getById(3);
    }

}

$felix = new Personne();
$felix->setNom("sportelli");
//echo $felix->getNom();
$felix->setAge(32);

$jerome = new Personne();
$jerome->setNom("SOUrdIN");
$jerome->setAge(41);

//echo $felix->age;
echo $felix->disBonjour() . "<br />";
echo $jerome->disBonjour(). "<br />";

$frederique = new Fonctionnaire();
$frederique->setTitularise(true);
var_dump($frederique->isTitulaire());
echo "<br/>";
$frederique->setNom("ROGER");
$frederique->setAge(1);
echo $frederique->disBonjour();

echo "<br/>";
$aff = new Affichage();
echo $aff->go($felix);
echo $aff->go($frederique);

echo $aff->go2($frederique);
echo $aff->go2($felix);