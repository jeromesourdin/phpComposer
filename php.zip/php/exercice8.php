<?php

$age = 20; 
$majeur = 18;

if ($age<$majeur){
    echo "mineur";
} elseif ($age==$majeur){
    echo "pile!";
} else {
    echo "majeur";
}