<?php

// Lecture de fichiers 
$fichier = "resources/monfichier.txt";
$file = new SplFileObject($fichier, "r");
foreach ($file as $line) {
    echo "$line <br />";
}

$ligneAEcrire = "\nnouvelle ligne";
$file = new SplFileObject($fichier, "a");
$file->fwrite($ligneAEcrire);

$fichier = "resources/monfichier.txt";
$file = new SplFileObject($fichier, "r");
foreach ($file as $line) {
    echo "$line <br />";
}

echo "<br /><br />";
$fichierCSV = "resources/fichier.csv";
$file = new SplFileObject($fichierCSV, "r");
$file->setFlags(SplFileObject::READ_CSV);
$file->setCsvControl(";",'"','"');

foreach ($file as $line) {
    print_r($line);
    echo "<br />";
}

$list = array (
    array('aaa', 'bbb', 'ccc', 'dddd'),
    array('123', '456', '789'),
    array('aaa', 'bbb')
);

$file = new SplFileObject('resources/file.csv', 'w');
$file->setCsvControl(";");

foreach ($list as $fields) {
    $file->fputcsv($fields);
}