<?php

var_dump(2==3); echo "<br/>";
var_dump(2=="2");echo "<br/>";
var_dump(2==="2");echo "<br/>";
var_dump(2!=3);echo "<br/>";
var_dump(2>3);echo "<br/>";
var_dump(2>=3);echo "<br/><br/>";

// PHP 7 (Space ship operator)
var_dump(2<=>3);echo "<br/>"; 
var_dump(3<=>3);echo "<br/>"; 
var_dump(4<=>3);echo "<br/>"; 

