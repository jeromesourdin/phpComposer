<?php
namespace FormationPHP;

use FormationPHP\service\UserService;
use FormationPHP\exceptions\UtilisateurInconnuException;

// Charger l'autoload
require __DIR__ . "/../vendor/autoload.php";

echo "je suis dans index <br/>";

// $userService = new service\UserService();
$userService = new UserService();
var_dump($userService->recupByIdentifiant("felix"));
echo "<br /><br />";

try {
    var_dump($userService->recupByIdentifiant("tititt"));
} catch (UtilisateurInconnuException $e) {
    echo "Erreur : " . $e->getMessage();
}
catch (\Exception $e){
    echo "erreur systeme - merci de réessayer";
}