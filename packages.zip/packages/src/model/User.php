<?php
namespace FormationPHP\model;

class User
{
    /**
     * Table utilisateurs / Champs u_id
     * 
     * @var int 
     */
    private $id;

    /**
     * Table utilisateurs / Champs u_email
     * 
     * @var string 
     */
    private $email;

    /**
     * Table utilisateurs / Champs u_identifiant
     * 
     * @var string 
     */
    private $identifiant;

    /**
     * Table utilisateurs / Champs u_motdepasse
     * 
     * @var string 
     */
    private $motdepasse;

    /**
     * Table adresse 
     * 
     * @var Adress
     */
    private $adresse;

    /**
     * @return mixed
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * @param mixed $id
     *
     * @return self
     */
    public function setId($id)
    {
        $this->id = $id;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getEmail()
    {
        return $this->email;
    }

    /**
     * @param mixed $email
     *
     * @return self
     */
    public function setEmail($email)
    {
        $this->email = $email;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getIdentifiant() : string
    {
        return $this->identifiant;
    }

    /**
     * @param mixed $identifiant
     *
     * @return self
     */
    public function setIdentifiant(string $identifiant)
    {
        $this->identifiant = $identifiant;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getMotdepasse()
    {
        return $this->motdepasse;
    }

    /**
     * @param mixed $motdepasse
     *
     * @return self
     */
    public function setMotdepasse($motdepasse)
    {
        $this->motdepasse = $motdepasse;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getAdresse()
    {
        return $this->adresse;
    }

    /**
     * @param mixed $adresse
     *
     * @return self
     */
    public function setAdresse($adresse)
    {
        $this->adresse = $adresse;

        return $this;
    }
}