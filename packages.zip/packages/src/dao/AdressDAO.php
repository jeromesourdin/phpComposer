<?php
namespace FormationPHP\dao;

use FormationPHP\model\Adress;

class AdressDAO 
{

    public function getByUserId(int $userId)
    {
        $sql = "SELECT a_id,a_numero,a_voie,a_ville,a_user_id FROM adresse where a_user_id=:userId";

        // Récupération du "statement" (curseur qui va parcourir les résultats)
        $stmt = $this->pdo->prepare($sql);
        $stmt->execute( ["userId" => $userId] );

        $adress = null;
        while ( $ligne = $stmt->fetch())
        {
            $adress = new Adress();
            $adress->setNumero($ligne["a_numero"]);
            $adress->setVoie($ligne["a_voie"]);
            $adress->setVille($ligne["a_ville"]);
        }
        return $adress;
    }

    function __construct()
    {
        $hostDB = "127.0.0.1";
        $userDB = "formation";
        $passDB = "formation";
        $nameDB = "formation";
        $charset = "utf-8";

        // Chaine de connexion (toutes les informations dont PDO a besoin)
        $dsn = "mysql:host=$hostDB;dbname=$nameDB";
        $this->pdo = new \PDO($dsn, $userDB, $passDB);
    }
}