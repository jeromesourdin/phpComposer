<?php

use PHPUnit\Framework\TestCase;
use FormationPHP\service\UserService;
use FormationPHP\dao\UserDAO;
use FormationPHP\model\User;
use FormationPHP\exceptions\UtilisateurInconnuException;

class UserServiceTest extends TestCase
{
    public function testRecupByIdentifiant()
    {
        $userService = new UserService();
        $user = $userService->recupByIdentifiant("felix");

        // Permet de verifier que $user n'est pas un entier, string .. 
        // mais une instance de la classe User
        $this->assertInstanceOf(User::class, $user);

        $this->assertTrue( $user->getIdentifiant() == "felix" );
        $this->assertTrue( $user->getId() == 1 );
        $this->assertTrue( $user->getEmail() == "felix@sportelli.org" );
    }

    public function testRecupByIdentifiantException()
    {
        $userService = new UserService();

        // J'indique à PHPUnit que je devrai recevoir une exception
        $this->expectException(UtilisateurInconnuException::class);

        $user = $userService->recupByIdentifiant("");        

    }

    public function testRecupByIdentifiantMock()
    {
        
        $user = new User();
        $user->setId(1);
        $user->setIdentifiant("xx");
        $user->setEmail("felix@sportelli.capital");
        
        $userDAO = $this->createMock(UserDAO::class);
        $userDAO
        ->method('getByIdentifiant')
        ->willReturn($user);
        
        $userService = new UserService($userDAO);

        $userReturn = $userService->recupByIdentifiant("felix");        
        $this->assertTrue( $userReturn->getIdentifiant() == "xx" );
        $this->assertTrue( $userReturn->getId() == 1 );
        $this->assertTrue( $userReturn->getEmail() == "felix@sportelli.capital" );
        $this->assertInstanceOf(User::class, $userReturn);
    }

}